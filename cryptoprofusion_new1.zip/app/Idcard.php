<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Idcard extends Model
{
    //
}
