<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid pb-5">
    <div class="row">
        <!-- side nav -->
        <?php echo $__env->make('partials.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- side nav ends -->
        <!-- page content -->
        <div class="col-lg-9 ml-sm-auto col-xl-10 pl-3 pr-5 px-xl-5 pt-1">
            
            <div class="row pt-md-4">
                <div class="col-12">
                    <h5 class="text-muted">Profile</h5>
                </div>
            </div>

            <div class="row offset-lg-1 ml-1 mt-2 mt-lg-5">
                <div class="col-12 col-lg-10">
                    <?php if(session("error")): ?>
                    <div class="alert alert-danger text-center" role="alert"><?php echo e(session("error")); ?></div>
                    <?php endif; ?>
                    <?php if(session("success")): ?>
                    <div class="alert alert-success text-center" role="alert"><?php echo e(session("success")); ?></div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-12 col-lg-7 offset-lg-5">
                            <img class="img-fluid rounded-circle" src="<?php echo e($user->photo); ?>" alt="profile_picture" />
                        </div>
                        <div class="col-12 col-lg-7 offset-lg-5 mt-lg-2">
                            <button class="btn btn-primary">Upload image</button>
                        </div>
                        <div class="col-12">
                            <form method="POST" action="/user/profile">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-group mb-4">
                                    <label for="fullname" class="text-muted">Full Name</label>
                                    <input type="fullname" class="form-control form-control-lg" name="fullname"
                                        placeholder="Fullname" id="fullname" value="<?php echo e($user->fullname); ?>" required>
                                </div>
                                <div class="form-row mb-2">
                                    <div class="form-group col-md-6">
                                        <label for="email" class="text-muted">Email</label>
                                        <input type="fullname" class="form-control form-control-lg" name="email"
                                            placeholder="Email" id="email" value="<?php echo e($user->email); ?>" required>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="phone" class="text-muted">Phone</label>
                                        <input type="tel" id="phone" class="form-control form-control-lg" name="phone"
                                            placeholder="Phone" value="<?php echo e($user->phone); ?>" required>
                                    </div>
                                </div>

                                <div class="form-group mb-4">
                                    <label for="phone" class="text-muted">Bitcoin Address</label>
                                    <input type="text" class="form-control form-control-lg" name="wallet_address"
                                        placeholder="Wallet Address"
                                        value="<?php echo e(empty($user->wallet->address) ? '' : $user->wallet->address); ?>"
                                        required>
                                </div>
                                <button type="submit" class="btn px-5 py-2 text-white"
                                    style="background: #76A140;">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- Page content ends -->
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tino/Desktop/cryptoprofusion/resources/views/user/profile.blade.php ENDPATH**/ ?>