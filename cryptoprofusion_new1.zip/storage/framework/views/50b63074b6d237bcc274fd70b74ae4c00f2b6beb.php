<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid pb-5">
    <div class="row">
        <!-- side nav -->
        <?php echo $__env->make('partials.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- side nav ends -->
        <!-- page content -->
        <div class="col-lg-9 ml-sm-auto col-xl-10 pl-3 pr-5 px-xl-5 pt-1">
            <div class="row pt-md-4">
                <div class="col-12">
                    <h4 class="text-muted">Pending Users Identity Cards</h4>
                </div>
            </div>

            <div class="container">
                <div class="row mt-2">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th scope="col" class="text-muted" style="font-weight: 400;">S/N</th>
                                    <th scope="col" class="text-muted" style="font-weight: 400;">Name</th>
                                    <th scope="col" class="text-muted" style="font-weight: 400;">ID link</th>
                                    <th scope="col" class="text-muted" style="font-weight: 400;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($idproofs) > 0): ?>
                                <?php for($i = 0; $i < count($idproofs); $i++): ?> <tr>
                                    <th scope="row"><?php echo e($i+1); ?></th>
                                    <td><?php echo e($idproofs[$i]->name); ?></td>
                                    <td><a href="<?php echo e($idproofs[$i]->idurl); ?>" target="_blank"
                                            class="text-primary">View</a></td>
                                    <td>
                                        <form action="/admin/verifyUserId" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" name="userId" value="<?php echo e($idproofs[$i]->userId); ?>">
                                            <button type="submit" class="btn btn-primary text-white">Verify user</button>
                                        </form>
                                    </td>
                                    </tr>
                                    <?php endfor; ?>
                                <?php else: ?>
                                    <tr><td><div class="text-center text-muted">No uploaded id yet</div></td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="ml-auto mr-3"><?php echo e($idproofs->links()); ?></div>
                </div>
            </div>

        </div>
        <!-- Page content ends -->
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tino/Desktop/cryptoprofusion/resources/views/admin/uploaded-ids.blade.php ENDPATH**/ ?>