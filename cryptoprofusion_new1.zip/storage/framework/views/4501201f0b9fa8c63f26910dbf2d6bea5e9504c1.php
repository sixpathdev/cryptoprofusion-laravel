<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid pb-5">
    <div class="row">
        <!-- side nav -->
        <?php echo $__env->make('partials.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- side nav ends -->
        <!-- page content -->
        <div class="col-lg-9 ml-sm-auto col-xl-10 pl-3 pr-5 px-xl-5 pt-1">
            <div class="row pt-md-4">
                <div class="col-12">
                    <h4 class="text-muted">Dashboard</h4>
                </div>
            </div>

            <div class="row mt-2">
                <div class="col-12 col-lg-8 offset-lg-2">
                    <?php if(session("success")): ?>
                    <div class="alert alert-success text-center" role="alert"><?php echo e(session("success")); ?></div>
                    <?php endif; ?>
                    <?php if(session("error")): ?>
                    <div class="alert alert-danger text-center" role="alert"><?php echo e(session("error")); ?></div>
                    <?php endif; ?>
                </div>
                <div class="col-12 mb-2 col-lg-6 mb-lg-0">
                    <div class="card">
                        <div class="card-body py-5">
                            <p class="h3 text-center">Total Deposited</p>
                            <p class="h3 text-center"><?php echo e('$'.$total_deposited_amount); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-12 mb-2 col-lg-6 mb-lg-0">
                    <div class="card">
                        <div class="card-body py-5">
                            <p class="h3 text-center">Total Referrals</p>
                            <p class="h3 text-center">$0</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-12 col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <span class="d-block h6 font-weight-bold py-2">DEPOSIT HISTORY</span>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr class="text-center text-white">
                                            <th scope="col">Payment ID</th>
                                            <th scope="col">Wallet Address</th>
                                            <th scope="col">Payment Date</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php for($i = 0; $i < count($mytransactions); $i++): ?> <tr
                                            class="text-center text-white">
                                            <th scope="row"><?php echo e($i+1); ?></th>
                                            <td><?php echo e($mytransactions[$i]->bitcoin_address); ?></td>
                                            <td><?php echo e($mytransactions[$i]->created_at); ?></td>
                                            <td
                                                class="font-weight-bold <?php echo e($mytransactions[$i]->payment_status == 'pending' ? 'text-danger' : 'text-success'); ?>">
                                                <span class="p-2"
                                                    style="background: white;border-radius:20px;"><?php echo e($mytransactions[$i]->payment_status); ?></span>
                                            </td>
                                            <td>
                                                <?php if($mytransactions[$i]->payment_status == 'pending'): ?>
                                                <form action="/admin/verifypayment" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <input type="hidden" name="txid"
                                                        value="<?php echo e($mytransactions[$i]->id); ?>">
                                                    <input type="hidden" name="userId"
                                                        value="<?php echo e($mytransactions[$i]->userId); ?>">
                                                    <button type="submit" name="submit"
                                                        class="btn bg-primary text-white">Verify</button>
                                                </form>
                                                <?php else: ?>
                                                <button type="submit" name="submit"
                                                    class="btn bg-success text-white">Verified</button>
                                                <?php endif; ?>
                                            </td>
                                            </tr>
                                            <?php endfor; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ml-auto mr-3"><?php echo e($mytransactions->links()); ?></div>
            </div>

        </div>
        <!-- Page content ends -->
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tino/Desktop/cryptoprofusion/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>