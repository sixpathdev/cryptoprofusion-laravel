<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" style="display: block !important;" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="container">
            <p class="text-warning">You are required to Update your <b>BITCOIN WALLET ADDRESS</b> before making any deposit.</p>
        </div>
      </div>
    </div>
  </div>


  {{-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> --}}