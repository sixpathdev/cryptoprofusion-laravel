<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid pb-5">
    <div class="row">
        <!-- side nav -->
        <?php echo $__env->make('partials.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- side nav ends -->
        <!-- page content -->
        <div class="col-lg-9 ml-sm-auto col-xl-10 pl-3 pr-5 px-xl-5 pt-1">
            <div class="row pt-md-4">
                <div class="col-12">
                    <h5 class="text-muted">Profile</h5>
                </div>
            </div>

            <div class="row offset-1 mt-2 mt-lg-5">
                <div class="col-10">
                    <?php if(session("error")): ?>
                    <div class="alert alert-danger" role="alert"><?php echo e(session("error")); ?></div>
                    <?php endif; ?>
                    <?php if(session("success")): ?>
                    <div class="alert alert-success" role="alert"><?php echo e(session("success")); ?></div>
                    <?php endif; ?>
                    <form method="POST" action="/user/profile">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group mb-4">
                            <input type="fullname" class="form-control form-control-lg" name="fullname" placeholder="Fullname"
                                id="fullname" value="<?php echo e($user->fullname); ?>">
                        </div>
                        <div class="form-row mb-2">
                            <div class="form-group col-md-6">
                                <input type="fullname" class="form-control form-control-lg" name="email" placeholder="Email"
                                    id="email" value="<?php echo e($user->email); ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <input type="tel" class="form-control form-control-lg" name="phone" placeholder="Phone"
                                    value="<?php echo e($user->phone); ?>">
                            </div>
                        </div>

                        <div class="form-group mb-4">
                            <input type="text" class="form-control form-control-lg" name="address" placeholder="Wallet Address"
                                value="<?php echo e($user->wallet->address); ?>">
                        </div>
                        <button type="submit" name="submit" class="btn px-5 py-2 text-white"
                            style="background: #76A140;">Update</button>
                    </form>
                </div>
            </div>

        </div>
        <!-- Page content ends -->
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tino/Desktop/cryptoprofusion/resources/views/user/profile.blade.php ENDPATH**/ ?>